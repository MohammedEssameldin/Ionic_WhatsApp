/// <reference path="./declarations/ContactsX.d.ts" />
